package com.crud.meuprimeirocrud;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MeuprimeirocrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(MeuprimeirocrudApplication.class, args);
	}

}
