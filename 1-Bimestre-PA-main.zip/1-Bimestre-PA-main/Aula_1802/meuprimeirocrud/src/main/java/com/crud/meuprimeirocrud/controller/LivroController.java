package com.crud.meuprimeirocrud.controller;

import com.crud.meuprimeirocrud.models.LivroModel;
import com.crud.meuprimeirocrud.service.LivroService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping(path = "/livros")
public class LivroController {
    @Autowired
    private LivroService livroService;

    @PostMapping
    private LivroModel criarLivro(@RequestBody LivroModel livroModel) {
        return livroService.criarLivro(livroModel);
    }

    @GetMapping
    private List<LivroModel> findAll(){
        return livroService.findAll();
    }

    @GetMapping("/{id}")
    public LivroModel getLivroById(@PathVariable Long id) {
        return livroService.getLivroById(id);

    }

}
