let xBolinha = 300;
let yBolinha = 200;
let diametro = 30;

let vxBolinha = 20;
let vyBolinha = 20;

let dxQ = 550;
let dyQ = 200;
let ddQ = 15;
let drQ = 100;

let exQ = 25;
let eyQ = 200;
let edQ = 15;
let erQ = 100;

function setup() {
    createCanvas(600, 400);
 }

 function draw() {

    background(0);

    criarBolinha();
    vBolinha();
    direcaoBolinha();

    rect(dxQ,dyQ,ddQ,drQ);
    rect(exQ,eyQ,edQ,erQ);
}

function criarBolinha(){
    circle(xBolinha,yBolinha,diametro);
}

function vBolinha(){
    xBolinha += vxBolinha;
    yBolinha += vyBolinha;
}

function direcaoBolinha(){
    if(xBolinha > width || xBolinha < 0){
        vxBolinha *= -1;
    }

    if(yBolinha > height || yBolinha < 0){
        vyBolinha *= -1;
    }
}