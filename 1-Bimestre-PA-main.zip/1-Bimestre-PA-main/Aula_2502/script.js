let xBolinha = 300;
let yBolinha = 200;
let diametro = 30;

let vxBolinha = 5;
let vyBolinha = 5;

let raio = diametro / 2;

let raqueteComprimento = 20;
let raqueteAltura = 100;

let xRaquete = 570;
let yRaquete = 150;

let xRaqueteOponente = 10;
let yRaqueteOponente = 150;

let posicao = xRaquete + yRaquete + raqueteComprimento + raqueteAltura;

function setup() {
    createCanvas(600, 400);
 }

 function draw() {

    background(0);
    criarBolinha();
    vBolinha();
    direcaoBolinha();
    criarRaquete(xRaquete,yRaquete);
    criarRaqueteOponente(xRaqueteOponente,yRaqueteOponente);
    movimentarRaquete();
    colisaoBolinhaRaquete();

    function criarBolinha(){
        circle(xBolinha,yBolinha,diametro);
    }
    
    function vBolinha(){
        xBolinha += vxBolinha;
        yBolinha += vyBolinha;
    }
    
    function direcaoBolinha(){
        if (xBolinha + raio > width ||
            xBolinha - raio < 0){
            vxBolinha *= -1;
        }
    
        if (yBolinha + raio > height ||
            yBolinha - raio < 0){
            vyBolinha *= -1;
        }
    }
    
    function criarRaquete(xRaquete,yRaquete){
        rect(xRaquete,yRaquete,raqueteComprimento,raqueteAltura);
    }

    function criarRaqueteOponente(xRaqueteOponente,yRaqueteOponente){
        rect(xRaqueteOponente,yRaqueteOponente,raqueteComprimento,raqueteAltura);
    }

    function movimentarRaquete(){
        if(keyIsDown(UP_ARROW)){
            if(yRaquete > height || yRaquete <=0){
                yRaquete = 0;
            }else {
            yRaquete -=10;
            }
        }
        if(keyIsDown(DOWN_ARROW)){
            if(yRaquete > height || yRaquete >=315){
                yRaquete = 315;
            }else {
            yRaquete +=10;
            }
        }
    }

    function colisaoBolinhaRaquete(){
        if (xBolinha + raio >= posicao){
            vxBolinha *= -1;
        }
    }

}

